insert into doctor(id,doctor_name,doctor_specialization,qualification_name) values(1,'john Wick','Neurology','MBBS,MD');
insert into doctor(id,doctor_name,doctor_specialization,qualification_name) values(2,'Dennis jackson','Anesthesiology','MBBS,MD');
insert into doctor(id,doctor_name,doctor_specialization,qualification_name) values(3,'Robert White','Surgeon','MBBS,MD');
insert into doctor(id,doctor_name,doctor_specialization,qualification_name) values(4,'Norm','Emergengy Medicine Specialists','MBBS');