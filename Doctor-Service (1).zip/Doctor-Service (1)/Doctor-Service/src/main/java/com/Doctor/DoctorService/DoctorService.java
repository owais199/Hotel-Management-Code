package com.Doctor.DoctorService;

import java.util.List;

public interface DoctorService {
    DoctorDTO saveDoctor(DoctorDTO doctorDTODto);

    public DoctorDTO getDoctorByName(String name);

    public DoctorDTO getDoctorBySpecialization(String specialization);

    public List<DoctorDTO> getAllDoctorDetails();
}