package com.Doctor.DoctorService;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DoctorRepo extends JpaRepository<Doctor, Long> {
    Doctor findByDoctorSpecialization(String doctorSpecialization);

    Doctor findByDoctorName(String Name);

    List<Doctor> findAll();

}