package com.Doctor.DoctorService;

import lombok.AllArgsConstructor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@AllArgsConstructor
public class ServiceImpl implements DoctorService {
    @Autowired
    private DoctorRepo doctorRepo;

    @Override
    public DoctorDTO saveDoctor(DoctorDTO doctorDTO) {

        Doctor d = new Doctor(doctorDTO.getId(), doctorDTO.getDoctorName(),
                doctorDTO.getDoctorSpecialization(), doctorDTO.getQualificationName());

        Doctor d1 = doctorRepo.save(d);

        DoctorDTO d2 = new DoctorDTO(d1.getId(), d1.getDoctorName(),
                d1.getDoctorSpecialization(), d1.getQualificationName());

        return d2;

    }

    @Override
    public DoctorDTO getDoctorByName(String name) {

        Doctor d = doctorRepo.findByDoctorName(name);
        DoctorDTO d1 = new DoctorDTO(d.getId(), d.getDoctorName(),
                d.getDoctorSpecialization(), d.getQualificationName());
        return d1;

    }

    @Override
    public DoctorDTO getDoctorBySpecialization(String specialization) {

        Doctor d = doctorRepo.findByDoctorSpecialization(specialization);
        DoctorDTO d1 = new DoctorDTO(d.getId(), d.getDoctorName(),
                d.getDoctorSpecialization(), d.getQualificationName());
        return d1;

    }

    @Override
    public List<DoctorDTO> getAllDoctorDetails() {

        List<Doctor> d = doctorRepo.findAll();
        List<DoctorDTO> d2 = new ArrayList<>();
        for (Doctor i : d) {
            DoctorDTO d3 = new DoctorDTO(i.getId(), i.getDoctorName(), i.getDoctorSpecialization(),
                    i.getQualificationName());

            d2.add(d3);

        }

        return d2;

    }
}