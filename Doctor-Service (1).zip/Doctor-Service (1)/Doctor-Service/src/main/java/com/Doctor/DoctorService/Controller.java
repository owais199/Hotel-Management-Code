package com.Doctor.DoctorService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

// import javax.print.Doc;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;

@RestController
@RequestMapping("/doctor-service")
@AllArgsConstructor
public class Controller {
    @Autowired
    private DoctorService doctorService;

    @PostMapping
    public ResponseEntity<DoctorDTO> saveDoctor1(@RequestBody DoctorDTO d) {
        DoctorDTO d1 = doctorService.saveDoctor(d);
        return new ResponseEntity<>(d1, HttpStatus.CREATED);
    }

    @GetMapping()
    public List<DoctorDTO> getAllDoctorDetails() {
        List<DoctorDTO> d1 = new ArrayList<>();
        d1 = doctorService.getAllDoctorDetails();
        return d1;
    }

    @GetMapping("/specialization/{specialization}")
    public ResponseEntity<DoctorDTO> getDoctorBySpecialization(@PathVariable("specialization") String specialization) {
        DoctorDTO d = doctorService.getDoctorBySpecialization(specialization);
        return new ResponseEntity<>(d, HttpStatus.OK);
    }

    @GetMapping("{name}")
    public ResponseEntity<DoctorDTO> getDoctorByName(@PathVariable("name") String name) {
        DoctorDTO d = doctorService.getDoctorByName(name);
        return new ResponseEntity<>(d, HttpStatus.OK);
    }
}