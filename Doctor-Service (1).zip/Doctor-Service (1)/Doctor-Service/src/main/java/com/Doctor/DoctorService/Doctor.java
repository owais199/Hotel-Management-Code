package com.Doctor.DoctorService;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Doctor {

    @Id
    private long id;
    // @GenerateValue(strategy=GenerationType.IDENTITY)

    @Column(name = "doctorName")
    private String doctorName;
    @Column(name = "doctorSpecialization")
    private String doctorSpecialization;
    @Column(name = "qualificationName")
    private String qualificationName;
}